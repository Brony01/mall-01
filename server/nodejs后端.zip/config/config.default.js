module.exports = {
    server_port: 8081,
    dataBase: "mongodb://localhost/react-mall",
    socketAddress: ''
}