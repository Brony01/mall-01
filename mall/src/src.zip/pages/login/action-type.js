export const LOGIN_USER_INFO = 'login_user_info';
export const LOG_OUT = 'log_out';
export const REGISTER_USER_INFO = 'register_user_info';
