import React, { Component, Suspense } from "react";
import { Redirect, Switch, Route } from "react-router-dom";
import { BackTop, Layout } from "antd";
import { connect } from "react-redux";
import Loadable from "react-loadable";
import HeaderSelf from "../../components/header";
import LeftNav from "../../components/left-nav";
import FooterComponent from "../../components/footer";
import Loading from "../../components/loading";
import AuthRouter from "../../components/AuthRouter";
import NotFoundPage from "../../components/404";

const Home = Loadable({
    loader: () => import("../home/home"),
    loading: Loading
});

const Category = Loadable({
    loader: () => import("../category/category"),
    loading: Loading
});

const Role = Loadable({
    loader: () => import("../role/role"),
    loading: Loading
});

const User = Loadable({
    loader: () => import("../user/user"),
    loading: Loading
});

const Product = Loadable({
    loader: () => import("../product"),
    loading: Loading
});

const GitHub = Loadable({
    loader: () => import("../github"),
    loading: Loading
});

const { Footer, Sider, Content } = Layout;

class Admin extends Component {
    state = {
        collapsed: false
    };

    onCollapse = collapsed => {
        this.setState({ collapsed });
    };

    render() {
        const { userInfo } = this.props;
        if (!userInfo._id) {
            return <Redirect to="/login" />;
        }
        return (
            <Layout style={{ minHeight: "100%" }}>
                <Sider
                    style={{ zIndex: 2 }}
                    collapsible
                    collapsed={this.state.collapsed}
                    onCollapse={this.onCollapse}
                >
                    <LeftNav collapsed={this.state.collapsed} />
                </Sider>
                <Layout>
                    <HeaderSelf />
                    <Content style={{ margin: "100px 14px 14px", background: "#fff" }}>
                        <Suspense fallback={<Loading />}>
                            <Switch>
                                <AuthRouter exact path="/" component={Home} />
                                <AuthRouter path="/home" component={Home} />
                                <AuthRouter path="/category" component={Category} />
                                <AuthRouter path="/product" component={Product} />
                                <AuthRouter path="/role" component={Role} />
                                <AuthRouter path="/user" component={User} />
                                <AuthRouter path="/github" component={GitHub} />
                                <AuthRouter component={NotFoundPage} />
                            </Switch>
                        </Suspense>
                    </Content>
                    <Footer style={{ textAlign: "center", background: "#fff" }}>
                        <FooterComponent />
                    </Footer>
                </Layout>
                <BackTop visibilityHeight={100} />
            </Layout>
        );
    }
}

const mapStateToProps = state => ({
    userInfo: state.loginUserInfo
});

export default connect(mapStateToProps, null)(Admin);
