export const SETHEADTITLE = 'set_head_title';
