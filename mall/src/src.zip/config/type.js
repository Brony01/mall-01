export default {
  BOX: 'box',
};
