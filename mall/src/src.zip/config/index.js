module.exports = {
  serverAddress: 'http://localhost:8081',
  baseURl: '/api',
  imgUrl: 'http://localhost:8081/upload/',
};
